function getRandomPrice() {
  return Math.floor(Math.random() * 10) * 100;
}

function getCurrentDateAndTime() {
  return new Date().toLocaleTimeString();
}

exports.getData = function () {
  const data = [
    {
      id: "01",
      name: "Product 01",
      price: getRandomPrice(),
      updatedAt: getCurrentDateAndTime(),
    },
    {
      id: "02",
      name: "Product 02",
      price: getRandomPrice(),
      updatedAt: getCurrentDateAndTime(),
    },
    {
      id: "03",
      name: "Product 03",
      price: getRandomPrice(),
      updatedAt: getCurrentDateAndTime(),
    },
    {
      id: "04",
      name: "Product 04",
      price: getRandomPrice(),
      updatedAt: getCurrentDateAndTime(),
    },
    {
      id: "05",
      name: "Product 05",
      price: getRandomPrice(),
      updatedAt: getCurrentDateAndTime(),
    },
    {
      id: "06",
      name: "Product 06",
      price: getRandomPrice(),
      updatedAt: getCurrentDateAndTime(),
    },
    {
      id: "07",
      name: "Product 07",
      price: getRandomPrice(),
      updatedAt: getCurrentDateAndTime(),
    },
    {
      id: "08",
      name: "Product 08",
      price: getRandomPrice(),
      updatedAt: getCurrentDateAndTime(),
    },
    {
      id: "09",
      name: "Product 09",
      price: getRandomPrice(),
      updatedAt: getCurrentDateAndTime(),
    },
    {
      id: "10",
      name: "Product 10",
      price: getRandomPrice(),
      updatedAt: getCurrentDateAndTime(),
    },
  ];

  return data;
};
