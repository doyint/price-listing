const { WebSocketServer, WebSocket } = require("ws");
const mockData = require("./mockdata");

const http = require("http");

const webSocketServerPort = 8080;
const server = http.createServer();

const webSocketServer = new WebSocketServer({ server });

webSocketServer.on("connection", (ws) => {
  let timer;
  timer = setInterval(() => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(mockData.getData()));
    } else {
      clearInterval(timer);
    }
  }, 1000);
});

server.listen(webSocketServerPort, () => {
  console.log(`Socket service is running ${webSocketServerPort}`);
});
