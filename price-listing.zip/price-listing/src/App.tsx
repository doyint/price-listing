import { useEffect, useState } from "react";
import "./App.css";
import Products from "./components/products/products";
import { ProductType } from "./types";

function App() {
  const [products, setProducts] = useState<[ProductType]>();
  const [isSubscribed, setIsSubscribed] = useState<boolean>(true);

  useEffect(() => {
    const ws: WebSocket = new WebSocket("ws://localhost:8080");
    ws.onopen = () => console.log("ws opened");
    ws.onclose = () => console.log("ws closed");
    ws.onmessage = (evt: MessageEvent) => {
      const products = JSON.parse(evt.data);
      setProducts(products);
    };

    if (!isSubscribed) {
      console.log("UnSubscribed");
      ws.close();
    }

    return () => ws.close();
  }, [isSubscribed]);

  const handleSubscription = () => {
    setIsSubscribed(!isSubscribed);
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Price List Table</h1>
      </header>

      {products ? (
        <Products products={products} />
      ) : (
        <div>No product loaded yet</div>
      )}

      <div>
        <button onClick={() => handleSubscription()}>
          {isSubscribed
            ? `Unsubscribe from price update`
            : `Subscribe to price update`}
        </button>
      </div>
    </div>
  );
}

export default App;
