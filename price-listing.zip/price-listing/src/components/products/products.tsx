import { FC } from "react";
import "./products.css";
import { ProductType } from "../../types";
import ProductItem from "./product-item";

const Products: FC<Props> = (props) => {
  const { products } = props;

  if (!products) return <div>No products</div>;

  return (
    <div className="Products">
      <table className="Products-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Price</th>
            <th>Updated At</th>
          </tr>
        </thead>
        <tbody>
          {}
          {products.map((product) => {
            return <ProductItem data={product} key={product.id} />;
          })}
        </tbody>
      </table>
    </div>
  );
};

interface Props {
  products?: Array<ProductType>;
}

export default Products;
