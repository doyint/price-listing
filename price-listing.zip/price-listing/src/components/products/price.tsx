import { FC } from "react";
import "./price.css";

const Price: FC<Props> = (props) => {
  const { price, previousPrice } = props;

  let priceIndicator = "";
  if (previousPrice) {
    priceIndicator = previousPrice > price ? "Price-down" : "Price-up";
  }

  return <div className={`Price ${priceIndicator}`}>{price}</div>;
};

interface Props {
  price: number;
  previousPrice: number | undefined;
}

export default Price;
