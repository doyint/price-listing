import { FC } from "react";
import usePrevious from "../../hooks/usePrevious";

import { ProductType } from "../../types";
import Price from "./price";

const ProductItem: FC<Props> = (props) => {
  const { name, price, updatedAt } = props.data;
  const prevPrice = usePrevious(price);

  if (!props.data) return <div>No products</div>;

  return (
    <tr>
      <td>{name}</td>
      <td>
        <Price price={price} previousPrice={prevPrice} />
      </td>
      <td>{updatedAt}</td>
    </tr>
  );
};

interface Props {
  data: ProductType;
}

export default ProductItem;
